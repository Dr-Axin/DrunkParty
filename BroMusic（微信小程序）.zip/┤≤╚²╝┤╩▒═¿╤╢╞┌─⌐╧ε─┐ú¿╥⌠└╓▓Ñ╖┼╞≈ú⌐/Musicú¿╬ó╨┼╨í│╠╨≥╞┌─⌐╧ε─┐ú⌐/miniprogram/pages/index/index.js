 //初始化数据库
const db = wx.cloud.database({})

//连接数据库
const getmlist = db.collection('musiclist')


Page({

  /**
   * 页面的初始数据
   */
  data: {
    item:0,
    tab:0,

    //播放列表初始化（id。cover，title，singer，src）
    playlist:[{
      _id: "",
      cover:'',
      title:'',
      singer:'',
       src:''
    }],

    state:'paused',
    playIndex:0,
    //播放器信息初始化
    play:{
      currentTime:'00:00',
      duration:'00:00',
      percent:0,
      title:'',
      singer:'',
      cover:''
    }
  },




//页面切换
changeItem:function(e){
  this.setData({
    item:e.target.dataset.item
  })
},

changeTab:function(e){
  this.setData({
    tab:e.detail.current
  })
},

  //从云开发数据库里列表
  getList() {
    let that = this;
    wx.cloud.callFunction({
      // 要调用的云函数名称
      name: 'getmlist',
      success: res => {
        wx.stopPullDownRefresh(); //如果数据传递成功停止刷新
        // console.log(res)
        if (res.result) {
          let playlist = res.result.data;//如果res成功'playlist'列表将会拿到res.result的数据
          console.log({
            playlist
          })//将列表数据打印到控制台
          if (playlist === undefined || playlist.length == 0) {//没有在该列表中被定义或者该列表是空则显示没有数据
            wx.showToast({
              title: '没有数据',
            })
          } else {
            that.setData({ //获取数据成功后的数据绑定
              isShowArticle: true,
              playlist: playlist,//将数据传到playlist
            },function(){
              //默认选择第一首
              this.setMusic(0)
            });
          }
        } else {
          wx.showToast({
            title: '没有数据',
          })
        }
      },
      fail: err => {
        wx.stopPullDownRefresh(); //如果数据传递失败停止刷新
        wx.showToast({
          title: '没有数据',
        })
      }
    })
},



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
     this.getList
 },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */

  audioCtx:null,
  onReady: function () {

    //创建InnerAudioComtext实例
    var audioCtx = wx.createInnerAudioContext()

    this.audioCtx = wx.createInnerAudioContext()
    
    var that = this

    //播放失败检测
    this.audioCtx.onError(function () {
      console.log('播放失败：' + that.audioCtx.src)
    })

    //播放完自动换下一曲
    this.audioCtx.onEnded(function () {
      that.next()
    })

    //自动更新播放进度
    this.audioCtx.onPlay(function(){})
    this.audioCtx.onTimeUpdate(function(){
      that.setData({
        'play.duration':formatTime(that.audioCtx.duration),
        'play.currentTime':formatTime(that.audioCtx.currentTime),
        'play.percent':that.audioCtx.currentTime / that.audioCtx.duration * 100
      })
    })


  
    //格式化时间
    function formatTime(time){
      var minute = Math.floor(time/60)%60;
      var second = Math.floor(time) % 60
      return(minute < 10 ? + minute:minute) + ':' + (second < 10? '0'+second:second)
    }
  },
  //设置播放的音乐
  setMusic:function(index){
    var music = this.data.playlist[index]
    console.log('1'+music)
    this.audioCtx.src = music.src
    this.setData({
      //当前播放的音乐信息
      'playIndex':index,
      'play.title':music.title,
      'play.singer':music.singer,
      'play.cover':music.cover,
      //播放页面滚动条设置
      'play.currentTime':'00:00',
      'play.duration':'00:00',
      'play.percent':0
    })
  },

  // 播放
  play: function () {
    this.audioCtx.play()//调用之前创建的多媒体实例进行play
    this.setData({
      state: 'running'
    })//数据进行设置，判断当前状态
  },
  //暂停
  pause: function () {
    this.audioCtx.pause()//调用之前创建的多媒体实例进行pause
    this.setData({
      state: 'paused'
    })
  },

  // 下一首
  next: function () {
    if (index=!0) {
      this.play()
       }
    //暂停歌曲
    this.pause()
    //判断当前的歌曲是否超出列表长度，若超过则从头开始播放，未超过就下一曲播放（设置了默认播放第一首）
    var index = this.data.playIndex  >=  this.data.playlist.length - 1 ? 0 : this.data.playIndex + 1
    this.setMusic(index)
  },

  //拖拽进度条
  sliderChange:function(e){
    //获取当前播放时间所对应的slider位置（拖拽的时间百分比*歌曲时长/100）
    var second = e.detail.value * this.audioCtx.duration / 100 
    this.audioCtx.seek(second)//跳转到指定位置
  },

  //换歌
  change:function(e){
    this.setMusic(e.currentTarget.dataset.index)
    this.play()
  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getList();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
      this.getList();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
        
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //页面相关事件处理函数--监听用户下拉动作
  onPullDownRefresh: function () {
    this.getList();
  }



})

