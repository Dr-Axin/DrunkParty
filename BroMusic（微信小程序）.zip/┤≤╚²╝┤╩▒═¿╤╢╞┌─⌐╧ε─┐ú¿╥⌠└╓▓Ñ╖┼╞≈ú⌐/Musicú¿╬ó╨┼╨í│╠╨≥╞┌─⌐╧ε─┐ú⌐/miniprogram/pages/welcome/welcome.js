Page({
    onTap: function (event) {
      // 跳转页面
        wx.navigateTo({
            url:"../index/index"
        });
        
    }
})