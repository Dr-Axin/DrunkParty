// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        SHOOT_POWER: 18,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.body = this.getComponent(cc.RigidBody);//获取球杆刚体组件

    },

    shoot_at: function(dst) {//球杆发射
        //冲量：p=ft给球杆一个方向的冲量，是一个矢量有大小和方向;
        //方向：当前位置src指向白球位置dst(src--->dst)
        var src = this.node.getPosition();
        let vec = dst.sub(src);

        //大小：
        var cue_len_half = this.node.width*0.5;
        let len = vec.mag();
        var distance  = len - cue_len_half;

        var power_x = distance * this.SHOOT_POWER * vec.x /  len;
        var power_y = distance * this.SHOOT_POWER * vec.y /  len;

        // 冲量函数applyLinearImpulse(冲量大小的向量，世界坐标的质心[球杆的中心]——>球杆的原点转成世界坐标，true[唤醒刚体用true])
        this.body.applyLinearImpulse(cc.p(power_x, power_y), this.node.convertToWorldSpaceAR(cc.p(0, 0), true));//给球杆刚体一个冲量
    },

    // 四种碰撞回调函数：
    // onBeginContact碰撞开始被调用
    // onEndContact碰撞结束被调用
    // onPreSolve碰撞接触更新前使用
    // onPostSolve碰撞接触更新后调用
    // 函数中的参数：1：contact：碰撞信息； 2：selfCollider：自己的碰撞器； 3：otherCollider：别人的碰撞器[撞到的谁]

    onPreSolve: function(contact, selfCollider, otherCollider) {
        this.node.active = false;
    }
    // update (dt) {},
});
