"use strict";
cc._RF.push(module, '191a3bGY85DPY6eCVqswLkN', 'game_sence');
// scripts/game_sence.js

"use strict";

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        ball_root: {
            type: cc.Node,
            default: null
        },
        white_ball: {
            type: cc.Node,
            default: null
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.is_game_started = true;
    },


    restart_game: function restart_game() {
        for (var i = 0; i < this.ball_root.childrenCount; i++) {
            var b = this.ball_root.children[i];
            b.getComponent("ball").reset(); //获取ball组件并调用reset函数
        }

        this.white_ball.getComponent("white_ball").reset();
        this.is_game_started = true;
    },

    check_game_over: function check_game_over() {
        for (var i = 0; i < this.ball_root.childrenCount; i++) {
            var b = this.ball_root.children[i];
            if (b.active === true) {
                return;
            }
        }

        this.is_game_started = false; //game_over;
        this.scheduleOnce(this.restart_game.bind(this), 5);
    },
    update: function update(dt) {
        if (!this.is_game_started) {
            return;
        }
        //是否所有的球都进洞了
    }
});

cc._RF.pop();