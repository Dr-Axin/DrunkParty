(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/white_ball.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '8dc03J6+c1GG61p5cCjoGis', 'white_ball', __filename);
// scripts/white_ball.js

"use strict";

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        cue: {
            type: cc.Node,
            default: null
        },
        min_dis: 20 //如果拖动的距离到白球的中心小于这个距离，那么就隐藏球杆，否则的话，显示球杆
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.body = this.getComponent(cc.RigidBody); // 获取白球的刚体
        this.cue_inst = this.cue.getComponent("cue"); //获取cue节点上球杆组件的实例
        //刷新时重置白球位置
        this.start_x = this.node.x;
        this.start_y = this.node.y;

        //白球监听4个事件：start：(点击开始) moved(触碰移动) ended(触摸在节点范围内弹起) cancel(节点范围外弹起)
        //this.node.on()打开监听   function(e) e会将底层的触摸参数和事件对象传递给我们   bind(this), this显示函数里面带this
        this.node.on(cc.Node.EventType.TOUCH_START, function (e) {//监听start事件

        }.bind(this), this);

        this.node.on(cc.Node.EventType.TOUCH_MOVE, function (e) {
            //监听moved事件

            //求取球杆所需方向
            var w_pos = e.getLocation(); //获取当前触摸位置
            var dst = this.node.parent.convertToNodeSpaceAR(w_pos); //将世界坐标系转变为白球节点的的父类节点的坐标系下
            var src = this.node.getPosition(); //获取得到当前白球的位置
            var vec = dst.sub(src); //方向向量=目标点-原点
            var distance = vec.mag(); //求向量的模长


            //求取球杆到白球中心的最小距离
            if (distance < this.min_dis) {
                this.cue.active = false; //如果小于最小距离条件成立，则设置球杆可视化属性为false
                return;
            }
            this.cue.active = true;

            //求取球杆所需旋转角度
            var r = Math.atan2(vec.y, vec.x); //反三角函数：求出dir方向向量的反三角度数
            var degree = r * 180 / Math.PI; //角度=r（弧度）*180°/π弧度
            degree = 360 - degree; //数学坐标系中的旋转角度是逆时针，而场景中的旋转角度为顺时针，因此需要转换，
            // 即：360°-场景中的角度=数学坐标系中所转角度
            this.cue.rotation = degree + 180; //将所求角度值给球杆

            //求取球杆所需拉伸的长度
            var cue_pos = dst; //获取球杆所在触摸点的位置 
            var cue_len_half = this.cue.width * 0.5; //求取球杆长度的一半
            cue_pos.x += cue_len_half * vec.x / distance;
            cue_pos.y += cue_len_half * vec.y / distance;

            this.cue.setPosition(cue_pos);
        }.bind(this), this);

        this.node.on(cc.Node.EventType.TOUCH_END, function (e) {
            //监听end事件
            if (this.cue.active === false) {
                //如果挥杆距离小于最小距离则取消挥杆
                return;
            }
            this.cue_inst.shoot_at(this.node.getPosition());
        }.bind(this), this);

        this.node.on(cc.Node.EventType.TOUCH_CANCEL, function (e) {
            //监听cancel事件
            if (this.cue.active === false) {
                //如果挥杆距离小于最小距离则取消挥杆
                return;
            }
            this.cue_inst.shoot_at(this.node.getPosition());
        }.bind(this), this);
    },

    reset: function reset() {
        //在重置函数中重新启动白球
        this.node.scale = 1;
        this.node.x = this.start_x;
        this.node.y = this.start_y;

        this.body.linearVelocity = cc.p(0, 0); // 规定重置时的白球线性速度为0
        this.body.angularVelocity = 0; // 规定重置时的白球角速度为0
    },

    onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
        //白球有可能碰球杆，有可能碰其他球，边，球袋
        if (otherCollider.node.groupIndex == 2) {
            //隔1秒后把白球放回原处；
            this.node.scale = 0; //重新封装定时器(相当于隐藏了白球)
            this.scheduleOnce(this.reset.bind(this), 1); //重新启动白球（重置）
            return;
        }
    }

    // update (dt) {},
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=white_ball.js.map
        